import React, { useState, useMemo } from 'react';
import { NGO, NgoCategory } from '../types';
import { NGOS, USER_STATS, updateUserProgress } from '../data/mockData';
import GlassmorphismPanel from '../components/GlassmorphismPanel';
import useLocalStorage from '../hooks/useLocalStorage';
import { CloseIcon } from '../components/Icons';

const Ngos: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<NgoCategory | 'All'>('All');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedNgo, setSelectedNgo] = useState<NGO | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [, setUserStats] = useLocalStorage('user-stats', USER_STATS);
  const [formData, setFormData] = useState({ name: '', email: '', item: '', description: '' });

  const filteredNgos = useMemo(() => {
    return NGOS.filter(ngo => {
      const matchesCategory = selectedCategory === 'All' || ngo.category === selectedCategory;
      const matchesSearch = ngo.name.toLowerCase().includes(searchTerm.toLowerCase()) || ngo.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [searchTerm, selectedCategory]);

  const handleOpenModal = (ngo: NGO) => {
    setSelectedNgo(ngo);
    setIsModalOpen(true);
    setShowConfirmation(false);
    setFormData({ name: '', email: '', item: '', description: '' });
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedNgo(null);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.item && selectedNgo) {
      const pointsEarned = 50;
      setUserStats(prev => ({
          ...prev, 
          points: prev.points + pointsEarned,
          progress: updateUserProgress(prev.progress, pointsEarned),
      }));
      setShowConfirmation(true);
    } else {
      alert('Please fill in all required fields.');
    }
  };

  const categories: (NgoCategory | 'All')[] = ['All', ...Object.values(NgoCategory)];
  
  const categoryColorMap: Record<NgoCategory, string> = {
    [NgoCategory.FOOD]: 'bg-rose-500/20 text-rose-300',
    [NgoCategory.CLOTHES]: 'bg-sky-500/20 text-sky-300',
    [NgoCategory.ELECTRONICS]: 'bg-amber-500/20 text-amber-300',
    [NgoCategory.EDUCATION]: 'bg-teal-500/20 text-teal-300',
  }

  return (
    <>
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8 text-violet-300">Find Local NGOs</h1>
        
        <GlassmorphismPanel className="p-4 mb-8 sticky top-20 z-10">
          <div className="flex flex-col md:flex-row gap-4">
            <input
              type="text"
              placeholder="Search for an NGO..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="flex-grow bg-black/30 border border-white/20 rounded-lg shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500 sm:text-sm"
            />
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 text-sm font-medium rounded-full whitespace-nowrap transition-colors ${selectedCategory === category ? 'bg-violet-500 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </GlassmorphismPanel>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredNgos.length > 0 ? (
            filteredNgos.map(ngo => (
              <GlassmorphismPanel key={ngo.id} className="overflow-hidden flex flex-col">
                <img src={ngo.imageUrl} alt={ngo.name} className="w-full h-48 object-cover"/>
                <div className="p-6 flex flex-col flex-grow">
                  <span className={`inline-block ${categoryColorMap[ngo.category]} text-xs font-semibold mr-2 px-2.5 py-0.5 rounded-full mb-2 self-start`}>
                    {ngo.category}
                  </span>
                  <h3 className="text-xl font-bold text-white mb-2">{ngo.name}</h3>
                  <p className="text-gray-300 flex-grow">{ngo.description}</p>
                  <p className="text-sm text-gray-400 mt-4">📍 {ngo.location}</p>
                </div>
                <div className="p-4 bg-black/20">
                    <button onClick={() => handleOpenModal(ngo)} className="w-full px-4 py-2 bg-violet-500 text-white font-semibold rounded-lg shadow-md hover:bg-violet-600 transition-colors">
                        Donate to this NGO
                    </button>
                </div>
              </GlassmorphismPanel>
            ))
          ) : (
            <p className="text-center text-gray-300 md:col-span-2 lg:col-span-3">No NGOs found matching your criteria.</p>
          )}
        </div>
      </div>

      {isModalOpen && selectedNgo && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <GlassmorphismPanel className="p-8 relative max-w-lg w-full">
            <button onClick={handleCloseModal} className="absolute top-2 right-2 p-1 rounded-full text-gray-300 hover:bg-white/10 hover:text-white transition-colors z-10">
              <CloseIcon className="w-6 h-6" />
            </button>
            
            {showConfirmation ? (
              <div className="text-center">
                 <div className="w-16 h-16 mx-auto mb-4 bg-violet-500/30 text-violet-300 rounded-full flex items-center justify-center text-3xl">✓</div>
                 <h2 className="text-2xl font-bold text-white mb-2">Thank You!</h2>
                 <p className="text-gray-300">Your donation request has been submitted. {selectedNgo.name} will contact you shortly. You've earned 50 eco-points!</p>
              </div>
            ) : (
              <>
                <h2 className="text-2xl font-bold text-white mb-2">Donate to {selectedNgo.name}</h2>
                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-300">Full Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500"/>
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-300">Email Address</label>
                        <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500"/>
                    </div>
                    <div>
                        <label htmlFor="item" className="block text-sm font-medium text-gray-300">Item(s) to Donate</label>
                        <input type="text" name="item" id="item" value={formData.item} onChange={handleChange} required placeholder="e.g., Winter Coats, Laptop, Canned Goods" className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500"/>
                    </div>
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium text-gray-300">Description (optional)</label>
                        <textarea name="description" id="description" value={formData.description} onChange={handleChange} rows={3} className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500"></textarea>
                    </div>
                    <button type="submit" className="w-full px-6 py-3 bg-violet-500 text-white font-bold rounded-lg shadow-md hover:bg-violet-600 transition-colors">
                        Arrange Donation
                    </button>
                </form>
              </>
            )}
          </GlassmorphismPanel>
        </div>
      )}
    </>
  );
};

export default Ngos;
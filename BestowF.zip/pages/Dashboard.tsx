import React from 'react';
import { USER_STATS } from '../data/mockData';
import useLocalStorage from '../hooks/useLocalStorage';
import GlassmorphismPanel from '../components/GlassmorphismPanel';
import DashboardChart from '../components/DashboardChart';

const Dashboard: React.FC = () => {
  const [userStats] = useLocalStorage('user-stats', USER_STATS);
  const { name, points, badges, progress } = userStats;

  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-4xl font-bold mb-2">Welcome Back, <span className="text-violet-300">{name}!</span></h1>
      <p className="text-lg text-gray-300 mb-8">Here's a look at your sustainable impact.</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
        <GlassmorphismPanel className="p-6 flex flex-col items-center justify-center">
          <h2 className="text-lg font-semibold text-gray-300">Total Eco-Points</h2>
          <p className="text-5xl font-bold text-violet-400">{points}</p>
        </GlassmorphismPanel>
        <GlassmorphismPanel className="p-6 col-span-1 md:col-span-2">
          <h2 className="text-lg font-semibold text-gray-300 mb-4">Your Badges</h2>
          <div className="flex flex-wrap gap-4">
            {badges.map(badge => (
              <div key={badge.name} className="flex items-center gap-3 bg-black/30 px-4 py-2 rounded-full" title={badge.name}>
                <span className="text-2xl">{badge.icon}</span>
                <span className="font-medium text-white">{badge.name}</span>
              </div>
            ))}
          </div>
        </GlassmorphismPanel>
      </div>
      
      <DashboardChart data={progress} />
    </div>
  );
};

export default Dashboard;
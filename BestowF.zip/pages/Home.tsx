import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import GlassmorphismPanel from '../components/GlassmorphismPanel';
import { LeafIcon, HeartIcon, UsersIcon } from '../components/Icons';

const useScrollAnimate = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    const elements = document.querySelectorAll('.animate-on-scroll');
    elements.forEach(el => observer.observe(el));

    return () => elements.forEach(el => observer.unobserve(el));
  }, []);
};

const AnimatedStat: React.FC<{ finalValue: number; label: string }> = ({ finalValue, label }) => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLDivElement>(null);
  
    useEffect(() => {
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) {
                let start = 0;
                const end = finalValue;
                if (start === end) return;
                
                const duration = 2000;
                const incrementTime = Math.max(10, duration / end);
                
                const timer = setInterval(() => {
                    start += Math.ceil(end/ (duration/incrementTime));
                    if (start > end) start = end;
                    setCount(start);
                    if (start === end) clearInterval(timer);
                }, incrementTime);
                observer.unobserve(ref.current!);
            }
        }, { threshold: 0.5 });
  
        if (ref.current) {
            observer.observe(ref.current);
        }
  
        return () => observer.disconnect();
    }, [finalValue]);
  
    return (
      <div ref={ref} className="text-center">
        <p className="text-4xl md:text-5xl font-bold text-teal-300">{count.toLocaleString()}+</p>
        <p className="text-gray-400 mt-1">{label}</p>
      </div>
    );
};

const Home: React.FC = () => {
  useScrollAnimate();

  return (
    <div className="max-w-7xl mx-auto text-center">
      <section className="min-h-[60vh] flex flex-col items-center justify-center animate-fade-in">
        <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-violet-300 to-teal-300 mb-4">
          Give with Purpose. Live Sustainably.
        </h1>
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-gray-300 mb-8">
          Bestow is a community dedicated to reducing waste and supporting those in need. Your unused items can have a second life and a lasting impact.
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/ngos"
            className="px-8 py-4 bg-violet-500 text-white font-semibold rounded-lg shadow-lg hover:bg-violet-600 transition-transform transform hover:scale-105 animate-pulse-glow"
          >
            Donate & Find NGOs
          </Link>
        </div>
      </section>

      <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
        <GlassmorphismPanel className="p-6 animate-on-scroll animate-fade-in-up">
          <h3 className="text-2xl font-semibold text-violet-300 mb-3">Find Local NGOs</h3>
          <p className="text-gray-300">
            Easily discover and connect with non-profits in your area that need the items you have. Filter by category to find the perfect match.
          </p>
        </GlassmorphismPanel>
        <GlassmorphismPanel className="p-6 animate-on-scroll animate-fade-in-up" style={{transitionDelay: '150ms'}}>
          <h3 className="text-2xl font-semibold text-violet-300 mb-3">Track Your Impact</h3>
          <p className="text-gray-300">
            Our dashboard visualizes your contribution. Earn eco-points, collect badges, and see the positive change you're creating.
          </p>
        </GlassmorphismPanel>
        <GlassmorphismPanel className="p-6 animate-on-scroll animate-fade-in-up" style={{transitionDelay: '300ms'}}>
          <h3 className="text-2xl font-semibold text-violet-300 mb-3">Get AI-Powered Tips</h3>
          <p className="text-gray-300">
            Our AI assistant provides creative ideas for reusing items, suggests donation opportunities, and offers daily sustainability tips.
          </p>
        </GlassmorphismPanel>
      </div>
      
      <section id="impact" className="mt-32 animate-on-scroll animate-fade-in-up">
        <h2 className="text-4xl font-bold text-center mb-8 text-violet-300">Our Impact</h2>
         <GlassmorphismPanel className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <AnimatedStat finalValue={1542} label="Items Donated" />
                <AnimatedStat finalValue={58} label="NGOs Partnered" />
                <AnimatedStat finalValue={750} label="Kg of Waste Reduced" />
            </div>
         </GlassmorphismPanel>
      </section>

      <section id="why-donate" className="mt-32 animate-on-scroll animate-fade-in-up">
        <h2 className="text-4xl font-bold text-center mb-8 text-violet-300">Why Your Donation Matters</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <GlassmorphismPanel className="p-6 text-center">
                <LeafIcon className="w-12 h-12 text-teal-300 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-white mb-3">Protect the Planet</h3>
                <p className="text-gray-300">
                    Reusing items is a powerful way to reduce landfill waste, conserve natural resources, and lower your carbon footprint.
                </p>
            </GlassmorphismPanel>
            <GlassmorphismPanel className="p-6 text-center" style={{transitionDelay: '150ms'}}>
                <HeartIcon className="w-12 h-12 text-rose-300 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-white mb-3">Help Those in Need</h3>
                <p className="text-gray-300">
                    Your pre-loved goods can become essential items for individuals and families facing hardship in your own community.
                </p>
            </GlassmorphismPanel>
            <GlassmorphismPanel className="p-6 text-center" style={{transitionDelay: '300ms'}}>
                <UsersIcon className="w-12 h-12 text-sky-300 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-white mb-3">Strengthen Community</h3>
                <p className="text-gray-300">
                    Donating locally fosters a sense of connection and supports the non-profits doing vital work right in your neighborhood.
                </p>
            </GlassmorphismPanel>
        </div>
      </section>

    </div>
  );
};

export default Home;
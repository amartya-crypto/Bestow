import React, { useState } from 'react';
import { GalleryPost } from '../types';
import { GALLERY_POSTS } from '../data/mockData';
import useLocalStorage from '../hooks/useLocalStorage';
import GlassmorphismPanel from '../components/GlassmorphismPanel';

const Gallery: React.FC = () => {
  const [posts, setPosts] = useLocalStorage<GalleryPost[]>('gallery-posts', GALLERY_POSTS);
  const [story, setStory] = useState('');
  const [author, setAuthor] = useState('');
  const [image, setImage] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!story || !author || !image) {
      alert('Please fill out all fields and upload an image.');
      return;
    }

    const newPost: GalleryPost = {
      id: Date.now(),
      author,
      story,
      imageUrl: image,
      timestamp: 'Just now',
    };

    setPosts([newPost, ...posts]);
    setStory('');
    setAuthor('');
    setImage(null);
    // Reset file input
    const fileInput = document.getElementById('imageUpload') as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  };

  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-4xl font-bold text-center mb-8 text-violet-300">Community Stories</h1>
      
      <GlassmorphismPanel className="p-6 mb-12">
        <form onSubmit={handleSubmit} className="space-y-4">
          <h2 className="text-2xl font-semibold text-white">Share Your Story</h2>
          <div>
            <label htmlFor="author" className="block text-sm font-medium text-gray-300">Your Name</label>
            <input type="text" id="author" value={author} onChange={e => setAuthor(e.target.value)} className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500 sm:text-sm"/>
          </div>
          <div>
            <label htmlFor="story" className="block text-sm font-medium text-gray-300">Your Story</label>
            <textarea id="story" value={story} onChange={e => setStory(e.target.value)} rows={4} className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500 sm:text-sm" placeholder="Tell us about your donation..."></textarea>
          </div>
          <div>
            <label htmlFor="imageUpload" className="block text-sm font-medium text-gray-300">Upload a Photo</label>
            <input type="file" id="imageUpload" accept="image/*" onChange={handleImageChange} className="mt-1 block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-violet-500/20 file:text-violet-300 hover:file:bg-violet-500/40 cursor-pointer"/>
          </div>
          {image && <img src={image} alt="Preview" className="mt-2 rounded-lg max-h-40" />}
          <button type="submit" className="w-full px-4 py-2 bg-violet-500 text-white font-semibold rounded-lg shadow-md hover:bg-violet-600 transition-colors">
            Share
          </button>
        </form>
      </GlassmorphismPanel>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {posts.map(post => (
          <GlassmorphismPanel key={post.id} className="overflow-hidden">
            <img src={post.imageUrl} alt="Donation story" className="w-full h-48 object-cover"/>
            <div className="p-6">
              <p className="text-gray-200 mb-2">"{post.story}"</p>
              <p className="font-semibold text-violet-300">- {post.author}</p>
              <p className="text-xs text-gray-400 mt-1">{post.timestamp}</p>
            </div>
          </GlassmorphismPanel>
        ))}
      </div>
    </div>
  );
};

export default Gallery;
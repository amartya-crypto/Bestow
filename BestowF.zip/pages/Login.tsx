import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import GlassmorphismPanel from '../components/GlassmorphismPanel';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim() === '') {
        alert('Please enter a username.');
        return;
    }
    // No security checks as requested
    login(username);
    navigate('/dashboard');
  };

  return (
    <div className="max-w-md mx-auto mt-10 md:mt-20 animate-fade-in">
      <GlassmorphismPanel className="p-8">
        <h1 className="text-3xl font-bold text-center mb-6 text-violet-300">Login to Bestow</h1>
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-300">
              Username
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500 sm:text-sm"
              required
              placeholder="Enter your name"
            />
          </div>
          <div>
            <label htmlFor="password"className="block text-sm font-medium text-gray-300">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full bg-black/30 border border-white/20 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-violet-500 focus:border-violet-500 sm:text-sm"
              placeholder="••••••••"
            />
             <p className="text-xs text-gray-400 mt-2">Any password will work. No security checks are in place.</p>
          </div>
          <button
            type="submit"
            className="w-full px-4 py-3 bg-violet-500 text-white font-semibold rounded-lg shadow-md hover:bg-violet-600 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-violet-500"
          >
            Access Dashboard
          </button>
        </form>
      </GlassmorphismPanel>
    </div>
  );
};

export default Login;

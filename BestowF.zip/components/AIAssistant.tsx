import React, { useState, useRef, useEffect } from 'react';
import { AiMessage } from '../types';
import { getAIResponse, getInitialAIResponse } from '../data/mockData';
import { SendIcon, CloseIcon } from './Icons';

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  context: string;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ isOpen, onClose, context }) => {
  const [messages, setMessages] = useState<AiMessage[]>([]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      const initialMessage = getInitialAIResponse(context);
      setMessages([{ sender: 'ai', text: initialMessage }]);
    }
  }, [isOpen, context]);
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (input.trim() === '') return;

    const userMessage: AiMessage = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    setTimeout(() => {
      const aiResponseText = getAIResponse(input);
      const aiMessage: AiMessage = { sender: 'ai', text: aiResponseText };
      setMessages(prev => [...prev, aiMessage]);
    }, 500);
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="w-full max-w-lg h-[80vh] flex flex-col bg-purple-900/50 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl overflow-hidden">
        <header className="flex items-center justify-between p-4 border-b border-white/10">
          <h3 className="text-lg font-semibold text-violet-300">AI Assistant</h3>
          <button onClick={onClose} className="p-1 rounded-full text-gray-300 hover:bg-white/10 hover:text-white transition-colors">
            <CloseIcon className="w-6 h-6" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, index) => (
            <div key={index} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-xs md:max-w-md px-4 py-2 rounded-2xl ${msg.sender === 'user' ? 'bg-violet-500 text-white rounded-br-none' : 'bg-gray-700/50 text-gray-200 rounded-bl-none'}`}>
                <p className="text-sm">{msg.text}</p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t border-white/10">
          <div className="flex items-center bg-gray-900/50 rounded-full border border-white/20">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask an eco-question..."
              className="flex-1 bg-transparent px-4 py-2 text-white placeholder-gray-400 focus:outline-none"
            />
            <button onClick={handleSend} className="p-2 text-violet-400 hover:text-violet-300 transition-colors m-1 rounded-full hover:bg-violet-500/20">
              <SendIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;
import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { CloudIcon, SyncIcon } from './Icons';
import { useAuth } from '../context/AuthContext';

const SyncStatus: React.FC = () => {
    const [isOnline, setIsOnline] = useState(navigator.onLine);
    const [statusText, setStatusText] = useState('Up to date');

    useEffect(() => {
        const handleOnline = () => setIsOnline(true);
        const handleOffline = () => setIsOnline(false);

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    useEffect(() => {
        if (isOnline) {
            setStatusText('Syncing...');
            const timer = setTimeout(() => setStatusText('Up to date'), 2000);
            return () => clearTimeout(timer);
        } else {
            setStatusText('Offline Mode');
        }
    }, [isOnline]);

    return (
        <div className="flex items-center gap-2 text-sm text-gray-400">
            {statusText === 'Syncing...' && <SyncIcon className="w-4 h-4 animate-spin"/>}
            {statusText === 'Up to date' && <CloudIcon className="w-4 h-4 text-teal-400"/>}
            {statusText === 'Offline Mode' && <CloudIcon className="w-4 h-4 text-gray-500"/>}
            <span>{statusText}</span>
        </div>
    );
};


const Navbar: React.FC = () => {
  const { isLoggedIn, logout } = useAuth();
  const navigate = useNavigate();

  const logoSrc = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAGQCAMAAAC3Ycb+AAAASFBMVEUAKADycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC7ycC6s5CdbAAAAF3RSTlMAgMC/gL9/31B/QCC/QCCvkI9w72B0TNEIAAADG0lEQVR42u3d24KiMBiGYQoKKoKgoqDi/q9sY2tIx9q22Xbsw9T/zV3MMlcmEwAAAAAAAAAAAAAAAACA/6R7PmM4/d4wHH9v+Pz+Gz7/9Q3/++03fP/jGz5/dMONEUPy/19/w4/Hh5/9m2G49/cNDx4b/vyjG/58bDj8/z08ePz9m2H4/FfDcO/fB+45+6vhe/j55+M/v35b+PnnY//h/Xth+P3fDcO3P2E4/h6G4fffn+Hffz88/vSH4ff/tOE/Pz88/vyn4fefv4cPP38Pj3/9s+Hn/7Ph59+G4fHjnx++h4f//B4e//7nww/w8PAnMPz5Dxj+/Jsx/PkvYPjzb2D48x8w/Pk3YfjzHzD8+Tdg+PNvYMj//g3M8PgnMHyG/+f+Dczw+CewfP4PzPD4J7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD4F7D8/g9s8PgnMPz+D2zw+Bew/P4PbPD450vM8PgnsHz+D8zw+CewfP4PzPD4J7B8/g/M8PgnsHz+D8zw+CewfP4PzPD4J7B8/g/M8PgnsHz+D8zw+CewfP4PzPB4/AvM8PgnMPz5PzDD4/8FZn78E5j58U9g5sc/gZkf/wRmfvwTmPnxT2Dmxz+BmT//B2b4/BMYvv8HZvj8E5j+/B+Y4fFPYOZ//wZmfvwTmPnx/wp+A/M/3mH4/j/D8P3/DcOf/wXD8/8Fw//8NcP/fA3D/3gNwwfw/T8M338Mwx/8y/B8/TUM//8tDP/5v2G4/1/g4V/g4Z/h4T/D8Id/gIf/CcP/fAXD/3wFw1/g4X/A8B/g4X/A8D/g4T/A8D/g4f/dMAAAAAAAAAAAAAAAAADgH31TAnG3H2fAAAAAAElFTkSuQmCC";

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Dashboard', path: '/dashboard' },
    { name: 'Local NGOs', path: '/ngos' },
  ];

  const linkClass = "px-3 py-2 rounded-md text-sm font-medium transition-colors";
  const activeLinkClass = "bg-violet-500/30 text-violet-300";
  const inactiveLinkClass = "text-gray-300 hover:bg-white/10 hover:text-white";

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-black/20 backdrop-blur-lg border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <NavLink to="/" className="flex-shrink-0">
              <img src={logoSrc} alt="Bestow Logo" className="h-8 w-8 object-contain" />
            </NavLink>
             <div className="hidden md:flex items-baseline space-x-4">
              {navLinks.map((link) => (
                <NavLink
                  key={link.name}
                  to={link.path}
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : inactiveLinkClass}`}
                >
                  {link.name}
                </NavLink>
              ))}
            </div>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <SyncStatus />
            {isLoggedIn ? (
              <button onClick={handleLogout} className="px-4 py-2 bg-violet-600 text-white rounded-md text-sm font-medium hover:bg-violet-700 transition-transform transform hover:scale-105 shadow-md">
                Logout
              </button>
            ) : (
              <NavLink to="/login" className="px-4 py-2 bg-violet-600 text-white rounded-md text-sm font-medium hover:bg-violet-700 transition-transform transform hover:scale-105 shadow-md">
                Login
              </NavLink>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
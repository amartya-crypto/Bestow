import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black/20 border-t border-white/10 mt-12">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 text-center text-gray-400">
        <p>&copy; {new Date().getFullYear()} Bestow. All rights reserved.</p>
        <p className="text-sm mt-1">Making the world better, one donation at a time.</p>
      </div>
    </footer>
  );
};

export default Footer;

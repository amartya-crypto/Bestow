import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import GlassmorphismPanel from './GlassmorphismPanel';

interface ChartData {
  month: string;
  points: number;
}

interface DashboardChartProps {
  data: ChartData[];
}

const DashboardChart: React.FC<DashboardChartProps> = ({ data }) => {
  return (
    <GlassmorphismPanel className="p-4 md:p-6">
       <h3 className="text-xl font-semibold text-violet-300 mb-4">Monthly Eco-Points</h3>
      <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer>
          <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.2)" />
            <XAxis dataKey="month" stroke="rgba(255, 255, 255, 0.7)" />
            <YAxis stroke="rgba(255, 255, 255, 0.7)" />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(30, 41, 59, 0.8)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                borderRadius: '0.75rem',
              }}
              labelStyle={{ color: '#c4b5fd' }}
            />
            <Legend wrapperStyle={{ color: 'white' }} />
            <Bar dataKey="points" fill="#8b5cf6" name="Eco-Points Earned" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </GlassmorphismPanel>
  );
};

export default DashboardChart;
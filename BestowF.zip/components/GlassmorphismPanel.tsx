import React from 'react';

// FIX: Extend component props to accept standard HTML attributes like 'style'.
interface GlassmorphismPanelProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

const GlassmorphismPanel: React.FC<GlassmorphismPanelProps> = ({ children, className = '', ...rest }) => {
  return (
    <div
      className={`bg-black/20 backdrop-blur-xl border border-white/20 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl ${className}`}
      {...rest}
    >
      {children}
    </div>
  );
};

export default GlassmorphismPanel;
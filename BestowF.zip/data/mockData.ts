import { NGO, NgoCategory, GalleryPost, UserStats } from '../types';

export const NGOS: NGO[] = [
  { id: 1, name: 'Goonj', category: NgoCategory.CLOTHES, description: 'A renowned organization focusing on clothing as a tool for rural development and disaster relief.', imageUrl: 'https://picsum.photos/seed/goonj/400/300', location: 'Sarita Vihar, Delhi' },
  { id: 2, name: 'The Akshaya Patra Foundation', category: NgoCategory.FOOD, description: 'Fighting classroom hunger with wholesome mid-day meals for school children.', imageUrl: 'https://picsum.photos/seed/akshaya/400/300', location: 'Badli Industrial Area, Delhi' },
  { id: 3, name: 'Digital Empowerment Foundation', category: NgoCategory.ELECTRONICS, description: 'Providing digital literacy and access to underserved communities using old and refurbished electronics.', imageUrl: 'https://picsum.photos/seed/digital/400/300', location: 'Hauz Khas, Delhi' },
  { id: 4, name: 'Smile Foundation', category: NgoCategory.EDUCATION, description: 'Empowering underprivileged children and youth through relevant education and healthcare.', imageUrl: 'https://picsum.photos/seed/smile/400/300', location: 'Saket, Delhi' },
  { id: 5, name: 'Uday Foundation', category: NgoCategory.FOOD, description: 'Distributing free food and relief supplies to homeless individuals and families in need.', imageUrl: 'https://picsum.photos/seed/uday/400/300', location: 'Adhchini, Delhi' },
  { id: 6, name: 'Asha Bhawan', category: NgoCategory.CLOTHES, description: 'A community that provides a home, food, clothing, and care for the poor and homeless.', imageUrl: 'https://picsum.photos/seed/asha/400/300', location: 'Gurugram, Haryana (NCR)' },
];

export const GALLERY_POSTS: GalleryPost[] = [
  { id: 1, author: 'Priya S.', timestamp: '3 days ago', story: 'So happy my old laptop found a new home with a student who needed it for their studies! Thanks, Bestow!', imageUrl: 'https://picsum.photos/seed/gallery1/600/400' },
  { id: 2, author: 'Rohan M.', timestamp: '1 week ago', story: 'Donated a box of winter coats to Goonj and it felt great knowing they would keep someone warm.', imageUrl: 'https://picsum.photos/seed/gallery2/600/400' },
];

export const USER_STATS: UserStats = {
  name: 'Alex',
  points: 1250,
  badges: [
    { name: 'First Donation', icon: '🎁' },
    { name: 'Eco-Warrior', icon: '🌿' },
    { name: 'Community Star', icon: '⭐' },
    { name: 'Recycle Ruler', icon: '♻️' }
  ],
  progress: [
    { month: 'Jan', points: 150 },
    { month: 'Feb', points: 300 },
    { month: 'Mar', points: 200 },
    { month: 'Apr', points: 450 },
    { month: 'May', points: 150 },
  ],
};

const AI_RESPONSES = {
  DEFAULT: [
    {
      keywords: ['hello', 'hi', 'hey', 'greetings', 'howdy'],
      response: [
        "Hello there! I'm Bestow's AI assistant. Ready to make a positive impact?",
        "Hi! I'm here to help with all things sustainable. What's on your mind?",
        "Greetings! How can I assist you in your sustainable journey today?"
      ]
    },
    {
      keywords: ['jar', 'bottle', 'glass container', 'plastic bottle'],
      response: [
        "Glass jars are super versatile! You can turn them into beautiful candle holders, mini plant pots, or stylish storage for your pantry. Just clean them out and let your creativity flow!",
        "Don't toss that bottle! Plastic bottles can be transformed into bird feeders, watering cans for your plants, or even vertical gardens. It's a fun DIY project!"
      ]
    },
    {
      keywords: ['clothes', 'shirt', 'fabric', 'jeans', 'textiles', 'old clothing'],
      response: [
        "Old t-shirts are a goldmine for DIY projects! You can cut them into strips to make braided rugs, tote bags, or even fun chew toys for a pet. If you're looking to donate, Goonj in Delhi is a fantastic option for fabric.",
        "Got old jeans? They can be repurposed into durable tote bags, cool patches for other clothes, or even a unique quilt. The possibilities are endless!"
      ]
    },
    {
      keywords: ['electronics', 'phone', 'cable', 'e-waste', 'computer', 'charger', 'battery'],
      response: [
        "E-waste needs special care! It's important to dispose of old electronics responsibly. Look for local e-waste recycling programs. In Delhi, the Digital Empowerment Foundation does great work refurbishing old gadgets for a good cause!",
        "Before you toss that old charger or phone, check if it can be donated! Many organizations accept them. Otherwise, make sure to find a certified e-waste recycling center to prevent harmful materials from ending up in landfills."
      ]
    },
    {
      keywords: ['food', 'leftovers', 'scraps', 'compost', 'kitchen waste'],
      response: [
        "Kitchen scraps can have a second life! Consider composting fruit and vegetable peels to create nutrient-rich soil for your garden. Some local community gardens even accept compost donations.",
        "Don't let leftovers go to waste! You can often repurpose them into new meals. Stale bread makes great croutons or bread pudding, and vegetable scraps can be used to make a flavorful broth."
      ]
    },
    {
      keywords: ['ngo', 'donate', 'where to give', 'charity', 'help', 'give away'],
      response: [
        "That's wonderful that you're looking to donate! Our 'Local NGOs' page has a curated list of amazing organizations. You can filter them by the type of items they need.",
        "You can find a perfect home for your pre-loved items by checking our NGO directory. It's a great way to support your local community directly."
      ]
    },
    {
      keywords: ['eco', 'sustainable', 'tips', 'go green', 'environment', 'how to be sustainable', 'reuse', 'upcycle', 'diy'],
      response: [
        "Starting your sustainability journey is exciting! A great first step is reducing single-use plastics. Try carrying a reusable water bottle and coffee cup. Small changes really do add up!",
        "Want a simple eco-tip? Switch to energy-efficient LED light bulbs. They use significantly less energy and last much longer than traditional bulbs, saving you money and helping the planet.",
        "You can make your shopping more sustainable by bringing your own reusable bags and choosing products with minimal packaging. Every choice is a chance to make a difference!"
      ]
    },
    {
      keywords: ['thanks', 'thank you', 'bye', 'goodbye', 'see you'],
      response: [
        "You're very welcome! Keep up the fantastic work. Every sustainable choice matters. Goodbye!",
        "Happy to help! Feel free to ask me anything else. Have a great day!",
        "My pleasure! Together, we're making the world a greener place. Farewell for now!"
      ]
    },
  ],
  CONTEXT: {
    '/gallery': 'Feeling inspired by the gallery? You can turn old jeans into a stylish tote bag or use wine corks to make a cool bulletin board. Ask me for more DIY ideas!',
    '/dashboard': 'Checking your progress? Awesome! A great way to earn more eco-points is by organizing a small donation drive in your neighborhood. Every little bit helps!',
    '/ngos': 'Looking for a place to donate? You can use the filters to find an NGO that specifically needs what you have. For example, "Goonj" is always looking for clothing and fabric.',
  },
  FALLBACK: [
      "That's an interesting question! I'm still learning about that. Could you try asking me about reusing items, finding NGOs, or general eco-friendly tips?",
      "I'm not quite sure how to answer that. I'm best at providing ideas for upcycling, connecting you with local charities, and sharing sustainability hacks. What would you like to know about those topics?",
      "My apologies, I don't have information on that. I can help with creative reuse ideas, donation questions, or eco-friendly living. How can I assist with those?"
  ]
};

export const getInitialAIResponse = (context: string): string => {
  return AI_RESPONSES.CONTEXT[context] || "Hello! I'm Bestow's AI assistant. Ask me about creative reuse, local NGOs, or eco-friendly tips!";
}

const getRandomResponse = (responses: string | string[]): string => {
    if (Array.isArray(responses)) {
        return responses[Math.floor(Math.random() * responses.length)];
    }
    return responses;
};

export const getAIResponse = (message: string): string => {
  const lowerCaseMessage = message.toLowerCase();
  for (const item of AI_RESPONSES.DEFAULT) {
    if (item.keywords.some(keyword => lowerCaseMessage.includes(keyword))) {
      return getRandomResponse(item.response);
    }
  }
  return getRandomResponse(AI_RESPONSES.FALLBACK);
};

export const updateUserProgress = (progress: { month: string; points: number; }[], pointsToAdd: number): { month: string; points: number; }[] => {
  const currentMonth = new Date().toLocaleString('default', { month: 'short' });
  const newProgress = [...progress];
  const monthIndex = newProgress.findIndex(p => p.month === currentMonth);

  if (monthIndex > -1) {
    newProgress[monthIndex].points += pointsToAdd;
  } else {
    // This case would be for a new month, but for simulation we just add to the last one if not found.
    if(newProgress.length > 0) {
       newProgress[newProgress.length-1].points += pointsToAdd;
    }
  }
  return newProgress;
};